// fibonacci.h
#ifndef FIBONACCI_H
#define FIBONACCI_H

#include <vector>
#include <stdexcept>

template <typename T>
class Fibonacci {
public:
    Fibonacci() = default;

    std::vector<T> getFirstN(int n) {
        if (!isValidInput(n)) {
            throw std::invalid_argument("Input must be a positive integer.");
        }

        std::vector<T> sequence;
        if (n >= 1) sequence.push_back(static_cast<T>(0));
        if (n >= 2) sequence.push_back(static_cast<T>(1));

        for (int i = 2; i < n; ++i) {
            sequence.push_back(sequence[i-1] + sequence[i-2]);
        }

        return sequence;
    }

private:
    bool isValidInput(int n) const {
        return n > 0;
    }
};

#endif // FIBONACCI_H
